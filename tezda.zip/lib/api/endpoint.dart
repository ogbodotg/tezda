class EndPoint {
  static const String baseUrl = 'fakestoreapi.com';
  static const String products = '/products';
}
